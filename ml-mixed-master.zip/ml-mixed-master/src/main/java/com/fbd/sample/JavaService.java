package com.fbd.sample;

public class JavaService {
    public void hello() {
        System.out.println("Hello from " + JavaService.class.getName());
    }
}
