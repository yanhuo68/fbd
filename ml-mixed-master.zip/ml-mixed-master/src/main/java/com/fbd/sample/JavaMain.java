package com.fbd.sample;

//import com.fbd.sample.ScalaService;
import com.fbd.ml.algorism.KmeansService;

public class JavaMain {
    public static void main(String[] args) {
        System.out.println("JavaMain starts");
  //      new ScalaService().hello();
  //      KmeansService.scalaTest();
        new KmeansService().scalaTest();
        
        System.out.println("JavaMain ends");
    }
}
