package com.fbd.ml.entry;

import com.fbd.ml.algorism.KmeansService;
import com.fbd.ml.algorism.Sample512App;

public class FBDMLJavaMain {

	public static void main(String[] args) {
//		String filename = null;
//		Integer schemaNbr = new Integer(5);
	
		System.out.println("FBD ML Java Main is starting !");
		Sample512App.execute();
//		if(args != null ){
//			if (args.length == 1  ){
//				new KmeansService().call(args[0], schemaNbr);
//			}else if(args.length == 2){
//				new KmeansService().call(args[0], new Integer(args[1]));
//			}else{
//				System.out.println("Incorrect parameters !!");
//			}
//		}
		System.out.println("FBD ML Java Main is completed !");
		System.exit(0);
	}

}
