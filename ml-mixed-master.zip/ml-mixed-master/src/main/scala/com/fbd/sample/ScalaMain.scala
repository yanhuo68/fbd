package com.fbd.sample

object ScalaMain extends App {
  println("ScalaMain starts")
  new JavaService().hello()
  println("ScalaMain ends")
}
