package com.fbd.sample

class ScalaService {
  def hello = println("Hello from " + classOf[ScalaService].getName)
}
