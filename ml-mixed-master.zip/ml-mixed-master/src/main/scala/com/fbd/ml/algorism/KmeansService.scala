package com.fbd.ml.algorism

//import org.apache.spark.mllib.clustering.KMeans
import org.apache.spark.mllib.clustering.GaussianMixture
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.util.MLUtils
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.mllib.clustering.{KMeans, KMeansModel}
//import org.apache.spark.mllib.regression.LinearRegressionWithSGD
//import org.apache.spark.mllib.regression.LabeledPoint
//import org.apache.spark.mllib.linalg.Vectors

class KmeansService {
  def call(filename : String, schema :Int){
    
//    val conf = new SparkConf()                                     //创建环境变量
//    .setMaster("local")                                             //设置本地化处理
//    .setAppName("KmeansService ")                              		//设定名称
//    val sc = new SparkContext(conf)                                 //创建环境变量实例
//    val data = MLUtils.loadLibSVMFile(sc, "Kmeans.txt")			//输入数据集
//    val parsedData = data.map(s => Vectors.dense(s.split(' ').map(_.toDouble))).cache()
//    val parsedData = data.map(s => Vectors.dense(s.split(' ').map(_.toDouble)))
//    .cache()												//数据处理

//    val numClusters = 2										//最大分类数
//    val numIterations = 20									//迭代次数
//    val model = KMeans.train(parsedData, numClusters, numIterations)	//训练模型
//    model.clusterCenters.foreach(println)							//打印中心点坐标
    
    // Load and parse the data
//      val data = sc.textFile("data/mllib/kmeans_data.txt")
//      val parsedData = data.map(s => Vectors.dense(s.split(' ').map(_.toDouble))).cache()
//      
//      // Cluster the data into two classes using KMeans
//      val numClusters = 2
//      val numIterations = 20
//      val clusters = KMeans.train(parsedData, numClusters, numIterations)
//      
//      // Evaluate clustering by computing Within Set Sum of Squared Errors
//      val WSSSE = clusters.computeCost(parsedData)
//      println("Within Set Sum of Squared Errors = " + WSSSE)
//      
//      // Save and load model
//      clusters.save(sc, "myModelPath")
//      val sameModel = KMeansModel.load(sc, "myModelPath")

    val conf = new SparkConf()                                     //创建环境变量
    .setMaster("local")                                             //设置本地化处理
    .setAppName("GMG ")                              			//设定名称
    val sc = new SparkContext(conf)                                 //创建环境变量实例
    val data = sc.textFile(filename)							//输入数个
    val parsedData = data.map(s => Vectors.dense(s.trim.split(' ')		//转化数据格式
    .map(_.toDouble))).cache()
    val model = new GaussianMixture().setK(2).run(parsedData)		//训练模型

    for (i <- 0 until model.k) {
      println("weight=%f\nmu=%s\nsigma=\n%s\n" format			//逐个打印单个模型
        (model.weights(i), model.gaussians(i).mu, model.gaussians(i).sigma))	//打印结果
    }
  }
  
    def scalaTest(){
  
      val conf = new SparkConf()                                     //创建环境变量
      .setMaster("local")                                             //设置本地化处理
      .setAppName("GMG ")                              			//设定名称
      val sc = new SparkContext(conf)                                 //创建环境变量实例
      val data = sc.textFile("/usr/yanhuo68/ml/sample.txt")							//输入数个
      val parsedData = data.map(s => Vectors.dense(s.trim.split(' ')		//转化数据格式
      .map(_.toDouble))).cache()
      val model = new GaussianMixture().setK(2).run(parsedData)		//训练模型
  
      for (i <- 0 until model.k) {
        println("weight=%f\nmu=%s\nsigma=\n%s\n" format			//逐个打印单个模型
          (model.weights(i), model.gaussians(i).mu, model.gaussians(i).sigma))	//打印结果
      }
  }
}
