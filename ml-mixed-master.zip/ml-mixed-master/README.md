fbd machine learning base
=========================

This is a maven project setup for a mixed scala and java project. 

You need to install JDK 1.8 or later and the latest maven first (3.3.x preferred).

+ git clone https://github.com/fbdmanager/ml-mixed.git
+ cd ml
+ mvn clean package
